#ifndef EVENT
#define EVENT


#include<iostream>
#include<cstdlib>
const int FLIPPING = 0;
const int WATCHING = 1;
const int DORMANT = 2;

class Event{
	public:
		Event(double,int,int,int,int,int);
		Event(const Event&);
		Event& operator=(const Event&);
		int get_previous_channel() { return previousChannel; }
		int get_current_channel()  { return currentChannel; }
		double getEventTime() const { return eventTime; }
		void addEventTime(int add) { eventTime+=add; }
		void set_user_id(int id) { user_id=id; }
		int get_user_id() { return user_id; }
	private:
		double eventTime; 
		int previousChannel; //When an event occurs,previousChannel indicates which channel the event depatures
		int currentChannel;// When an event occurs, currentChannel indicates which channel the event enters into
		int previousStatus;//Indicate the previous status of the event(FLIPPING or WATCHING)
		int currentStatus;//Indicate the current status of the event
		int user_id;// Every event has an user_id indicating which user the event belongs to
};

class sortevent{
	public:
		bool operator() (const Event& lhs, const Event& rhs ){
			return lhs.getEventTime()<rhs.getEventTime();
		}
};

#endif
