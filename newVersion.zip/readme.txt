852 project: SDV simulation
Name: Jing, Zhaoyu
mail: zjing@clemson.edu


How to run the program:
After decompress the HW4.tar.gz file, you could use the commands, make clean and make to generate the executable program. To test the code, you should input the parameters work as followings:
	./run <Npmr> <Nc> <Nslice> <simulationTime> <Shape> <Flipping behavior>

The parameter flipBehavior indicates the view's flipping behavior, which values from 1. Flip increasingly, 2. Flip decreasingly, 3.Flip randomly, 4.No Flipping. When choosing flipping randomly, the executing time of the program may be a little longer.

The Datafile.txt, which indicates how many channels are active over the simulation time and how many viewers are watching the channel , could be automatically generated in the same directory after running the program.

As for the no blocking, the nsdv, which refers to the total number of the channels under management and nslice, which represents the total availble channel resources that can be allocated for the user's request for a particular channel, should be the same, for example:
	./run 300 200 200 10000 1.0 1

When blocking may occer, the size of the nslice should be smaller than that of the nsdv, for example:
	./run 300 200 80 10000 1.0 4


	


