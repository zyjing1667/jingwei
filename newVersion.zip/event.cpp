#include "event.h"

Event::Event(double time, int pre, int cur, int pre_sta, int cur_sta,int id):
	eventTime(time),
	previousChannel(pre),
	currentChannel(cur),
	previousStatus(pre_sta),
	currentStatus(cur_sta),
	user_id(id)
{}

Event::Event(const Event& rhs):
	eventTime(rhs.eventTime),
	previousChannel(rhs.previousChannel),
	currentChannel(rhs.currentChannel),
	previousStatus(rhs.previousStatus),
	currentStatus(rhs.currentStatus),
	user_id(rhs.user_id)
{}

Event& Event::operator=(const Event& rhs){
	if(this!=&rhs){
		eventTime=rhs.eventTime;
		previousChannel=rhs.previousChannel;
		currentChannel=rhs.currentChannel;
		previousStatus=rhs.previousStatus;
		currentStatus=rhs.currentStatus;
		user_id=rhs.user_id;
	}
	return *this;
}

