#include <iostream>
#include "user.h"

User::User(double avgFliptime,int avgFlipchannel,double avgWatchtime,int Nsdv, double SimulationTime, double ZipfShape, int id, int flipBeha):
	avgFlipTime(avgFliptime),
	avgFlipChannel(avgFlipchannel),
	avgWatchTime(avgWatchtime),
	nsdv(Nsdv),
	simulTime(SimulationTime),
	zipfShape(ZipfShape),
	firstChannel(zipfRN(zipfShape,nsdv)-1),
	userId(id),
	flipBehavior(flipBeha),
	userBlocking(0),
	eventList(),
	each_user_event_size(0)
{  
	if(flipBehavior!=4&&flipBehavior!=5)
		handleFlip();
	else
		handleNoFlip();
}

User::User(const User& rhs):
	avgFlipTime(rhs.avgFlipTime),
	avgFlipChannel(rhs.avgFlipChannel),
	avgWatchTime(rhs.avgWatchTime),
	nsdv(rhs.nsdv),
	simulTime(rhs.simulTime),
	zipfShape(rhs.zipfShape),
	firstChannel(rhs.firstChannel),
	userId(rhs.userId),
	flipBehavior(rhs.flipBehavior),
	userBlocking(rhs.userBlocking),
	eventList(rhs.eventList),
	each_user_event_size(rhs.each_user_event_size)
{}

User& User::operator=(const User& rhs){
	if(this!=&rhs){
		avgFlipTime = rhs.avgFlipTime;
		avgFlipChannel = rhs.avgFlipChannel;
		avgWatchTime = rhs.avgWatchTime;
		nsdv=rhs.nsdv;
		simulTime = rhs.simulTime;
		zipfShape=rhs.zipfShape;
		firstChannel=rhs.firstChannel;
		userId=rhs.userId;
		flipBehavior=rhs.flipBehavior;
		userBlocking=rhs.userBlocking;
		eventList=rhs.eventList;
		each_user_event_size=rhs.each_user_event_size;
	}
	return *this;
}

//three kinds of user behavior: 1. flipUp; 2.flipDown; 3.flipRandomly
void User::handleFlip(){
	double time=rand_val(0)*10;

	//every user's first event, the previous channel here is initialized with -1
	Event event_flip_flip(time,-1,firstChannel,FLIPPING,FLIPPING,userId);
	eventList.push_back(event_flip_flip);
	int channel=firstChannel;

	//while the time is less than the simulation time, we generate the events for this user
	while(time<simulTime){

		// exponential distribution to generate the numbers of the user's flipping channel
		int temp=std::max(static_cast<int>(exponentialRN(1.0/avgFlipChannel)),1);

		//generate how much time a user maintains in one flipping channel
		double temp1=exponentialRN(1/avgFlipTime)/temp;	
		for(int i=0;i<temp-1;++i){
			time+=temp1;
			int preChannel=0;
			if(time>simulTime)
				break;
			if(flipBehavior==1)
				++channel;
			else if(flipBehavior==2)
				--channel;
			else if(flipBehavior==3){
				preChannel=channel;
				do{
					channel=zipfRN(zipfShape,nsdv)-1;
				}while(channel!=preChannel);
			}
		//If the channel reaches the number of nsdv, flip to channel 0
			if(channel>=nsdv){
				Event event_flip_flip(time,nsdv-1,nsdv-2,FLIPPING,FLIPPING,userId);
				eventList.push_back(event_flip_flip);
				channel=nsdv-2;
				flipBehavior=2;
			}
			else if(channel<=-1){
				Event event_flip_flip(time,0,1,FLIPPING,FLIPPING,userId);
				eventList.push_back(event_flip_flip);
				channel=1;
				flipBehavior=1;
			}
			else if(flipBehavior==1){
				Event event_flip_flip(time,channel-1,channel,FLIPPING,FLIPPING, userId);
				eventList.push_back(event_flip_flip);
			}
			else if(flipBehavior==2){
				Event event_flip_flip(time,channel+1,channel,FLIPPING,FLIPPING, userId);
				eventList.push_back(event_flip_flip);
			}
			else if(flipBehavior==3){
				Event event_flip_flip(time,preChannel,channel,FLIPPING,FLIPPING, userId);
				eventList.push_back(event_flip_flip);
			}
		}
		//flipping to watching(the last flipping channel in the flipping status)
		time+=temp1;
		if(time>simulTime)
			break;

		//Going to watching state, using zipf to select the channel which will be watched
		int watching_channel=zipfRN(zipfShape,nsdv)-1;
		Event event_flip_watch(time,channel,watching_channel,FLIPPING,WATCHING,userId);
		eventList.push_back(event_flip_watch);
		channel=watching_channel;

		//watching to flipping
		double temp3=exponentialRN(1/avgWatchTime);
		time+=temp3;
		if(time>simulTime)
			break;
		int preFlippingChannel=0;
		if(flipBehavior==1)
				++channel;
		else if(flipBehavior==2)
				--channel;
		else if(flipBehavior==3){
			preFlippingChannel=channel;
			do{
				channel=zipfRN(zipfShape,nsdv)-1;
			}while(channel!=preFlippingChannel);
		}
		if(channel>=nsdv){
			Event event_flip_flip(time,nsdv-1,nsdv-2,FLIPPING,FLIPPING,userId);
			eventList.push_back(event_flip_flip);
			channel=nsdv-2;
			flipBehavior=2;
		}
		else if(channel<=-1){
			Event event_flip_flip(time,0,1,FLIPPING,FLIPPING,userId);
			eventList.push_back(event_flip_flip);
			channel=1;
			flipBehavior=1;
		}
		else if(flipBehavior==1){
			Event event_flip_flip(time,channel-1,channel,FLIPPING,FLIPPING, userId);
			eventList.push_back(event_flip_flip);
		}
		else if(flipBehavior==2){
			Event event_flip_flip(time,channel+1,channel,FLIPPING,FLIPPING, userId);
			eventList.push_back(event_flip_flip);
		}
		else if(flipBehavior==3){
			Event event_flip_flip(time,preFlippingChannel,channel,FLIPPING,FLIPPING, userId);
			eventList.push_back(event_flip_flip);
		}
	}// Initialization for one user's events completed
		each_user_event_size=eventList.size();
}

//handleNoFlip: two kinds of user behavior: 4, dormant->watching; 5, watching until the end of simulation
void User::handleNoFlip(){
	double time=rand_val(0)*10;
	if(flipBehavior==5){
		Event event_dvr_watching(time,-1,firstChannel,DORMANT,WATCHING,userId);
		eventList.push_back(event_dvr_watching);
	}
	if(flipBehavior==4){
	//every user's first event, the previous channel here is initialized with -1
		Event event_dormant_watching(time,-1,firstChannel,DORMANT,WATCHING,userId);
		eventList.push_back(event_dormant_watching);
		int channel=firstChannel;
		while(time<simulTime){
			time+=exponentialRN(1/avgWatchTime);
			if(time>simulTime)
				break;
			Event event_watching_dormant(time,channel, nsdv+1 ,WATCHING,DORMANT,userId);
			eventList.push_back(event_watching_dormant);
			time+=exponentialRN(1/(avgFlipTime));
			if(time>simulTime)
				break;
			channel = zipfRN(zipfShape,nsdv)-1;
			Event event_dormant_watching(time,nsdv+1, channel,DORMANT,WATCHING,userId);
			eventList.push_back(event_dormant_watching);
		}
	}
		each_user_event_size=eventList.size();
}
		
	

