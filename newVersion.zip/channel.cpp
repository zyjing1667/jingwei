#include<iostream>
#include"channel.h"

Channel::Channel():
	actived(0),
	deactived(0),
	activationTime(0),
	number_users(0),
	ACTIVE(false)
{}
