#include<iostream>
#include<cstdlib>
#include<list>
#include<algorithm>
#include<ctime>
#include"event.h"
#include"user.h"
#include"channel.h"

class Scheduler{
	public:
		Scheduler(int,int,int,int,int,int,int,double,double,double,int,double);
		~Scheduler();
		Scheduler(const Scheduler&);
		Scheduler& operator=(const Scheduler&);
		void execute();
		void coreExecute(std::fstream&);
		//void noFlipExecute(std::fstream&);
		void set_max_channels(int activeChannels) {
			if(activeChannels>maxChannels)
				maxChannels=activeChannels;
		}
		void initEvents();
		void initEveryEvent(int,int,int);
		void initChannels();
		int getTotalViewers();
		void printStatus();
	private:
		// npmr, nsdv, nslice, simulationTime, zipfShape are passed by the input
		int npmrUp;
		int npmrDown;
		int npmrRandom;
		int npmrDormant;
		int npmrDvr;
		int nsdv;
		int nslice;
		double simulationTime;
	    double zipfShape;

		double avgFliptime;
		int avgFlipchannel;
		double avgWatchtime;
	
		//activeChannels refers to the current number of channels which are actived
		int activeChannels;

		//maxChannels refers to the max number of Channels that have been requested at one moment since the simulation starts
		int maxChannels;
		//vector users stores all the users
		std::vector<User> users;

		//vector events stores all the events, which are initialized by pushback all the users' events into the events
		std::list<Event> events;

		//channels stores all the channel, which will be updated during the excution of the scheduler.
		//At the end of the execution of the scheduler, the information in channels is used to calculate the average number of channels during the simulation
		std::vector<Channel> channels;
};


