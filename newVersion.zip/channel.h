#ifndef CHANNEL
#define CHANNEL

#include <iostream>

class Channel{
	public:
		Channel();
		void set_activation_time(int time) { activationTime+=(time-actived); }
		int get_activation_time() { return activationTime; }
		void set_actived_time(int time) { actived=time; }
		int get_actived_time() { return actived; }
		void set_deactived_time(int time) { deactived=time; }
		int get_deactived_time() { return deactived; }
		void set_numberofusers(int number) { number_users=number; }
		int get_numberofusers() { return number_users; }
		void set_ACTIVE(bool BOOL) { ACTIVE=BOOL; }
		bool get_ACTIVE() { return ACTIVE; }
	private:
		int actived; // the time when the channel is actived
		int deactived; // the time when the channel is deactived
		int activationTime; // the total activationTime, accumulated as the events occurs
		int number_users;// the number of users which are watching this channel
		bool ACTIVE;// flag indicating whether the channel is being watched or not
};

#endif
