#ifndef USER
#define USER

#include<iostream>
#include<cstdlib>
#include<list>
#include<vector>
#include<cmath>
#include"variates.h"
#include"event.h"


class User{
	public:
		friend class Scheduler;
		User(double, int, double, int, double, double, int, int );
		~User(){ eventList.clear(); }
		User(const User&);
		User& operator=(const User&);
		int get_event_number() { return eventList.size(); }
		int get_blocking() { return userBlocking; }
		void add_blocking() { ++userBlocking; }
		void handleFlip();
		void handleNoFlip();
	private:
	    double avgFlipTime;//average flipping time of a user, exponential distribute with mean of 10 seconds
		int avgFlipChannel;// average flipping channel numbers, exp distribute with mean of 6 channels
		double avgWatchTime;// average watching time, exp distribute with mean of 720 seconds
		int nsdv;// channels under management
		double simulTime;// simulation time
		double zipfShape;
		int firstChannel;
		int userId; // every user has a unique ID
		int flipBehavior;
		int userBlocking; // record every user's blocking times
		std::list<Event> eventList; // record every user's events
		int each_user_event_size; 
};

#endif

