#include"scheduler.h"

int main(int argc, char *argv[]){
	if(argc!=10){
	    std::cout<<"parameters:<NpmrUp> <NpmrDown> <NpmrRandom> <NpmrDormant> <NpmrDvr> <Nc> <Nslice> <SimulationTime> <ZipfShape>"<<std::endl;
	    return 0;
	}
	int NpmrUp=atoi(argv[1]);
	int NpmrDown=atoi(argv[2]);
	int NpmrRandom=atoi(argv[3]);
	int NpmrDormant=atoi(argv[4]);
	int NpmrDvr=atoi(argv[5]);
	int Nsdv=atoi(argv[6]); 
	int Nslice=atoi(argv[7]);
	int SimulationTime=atoi(argv[8]);
	double ZipfShape=atof(argv[9]);
	if(NpmrUp<0||NpmrDown<0||NpmrRandom<0||NpmrDormant<0||NpmrDvr<0){
	    std::cout<<"Npmr should be more than 0"<<std::endl;
	    return 0;
	}
	if(Nsdv<=0){
	    std::cout<<"Nc should be more than 0"<<std::endl;
	    return 0;
	}
	if(Nslice<=0){
	    std::cout<<"Nslice should be more than 0"<<std::endl;
		return 0;
	}
	if(SimulationTime<=0){
	    std::cout<<"SimulationTime should be more than 0"<<std::endl;
		return 0;
	}
	if(ZipfShape<=0){
		std::cout<<"ZipfShape should be more than 0"<<std::endl;
		return 0;
	}
	std::cout<<"Please enter the parameters for the flipping behavior of the user: <Average flipping time> <Average number of the flipping channels> <Average watching time>"<<std::endl;
	double avgFlipTime, avgWatchTime;
	int avgFlipChannel;
	std::cin>>avgFlipTime>>avgFlipChannel>>avgWatchTime;
    Scheduler scheduler(NpmrUp,NpmrDown,NpmrRandom,NpmrDormant,NpmrDvr,Nsdv,Nslice, SimulationTime,ZipfShape,avgFlipTime,avgFlipChannel,avgWatchTime);
    scheduler.execute();
    std::cout<<"simulation finished"<<std::endl;
}
