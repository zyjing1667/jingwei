#include<iostream>
#include "scheduler.h"

Scheduler::Scheduler(int NpmrUp,int NpmrDown,int NpmrRandom,int NpmrDormant,int NpmrDvr,int Nsdv,int Nslice,double SimulationTime,double ZipfShape,double avgFlipTime, int avgFlipChannel, double avgWatchTime):
	npmrUp(NpmrUp),
	npmrDown(NpmrDown),
	npmrRandom(NpmrRandom),
	npmrDormant(NpmrDormant),
	npmrDvr(NpmrDvr),
	nsdv(Nsdv),
	nslice(Nslice),
	simulationTime(SimulationTime),
	zipfShape(ZipfShape),
	avgFliptime(avgFlipTime),
	avgFlipchannel(avgFlipChannel),
	avgWatchtime(avgWatchTime),
	activeChannels(0),
	maxChannels(0),
	users(),
	events(),
	channels()
{
    srand((unsigned)time(NULL));
	rand_val(rand());
	zipfRN(zipfShape, nsdv);
	exponentialRN(0);
	//Initialize all the users.
	initEvents();
		//Initialize all the channels
	initChannels();
	//At this point all the events in the "events" of the scheduler have been initialized, then we use a function object to sort the events by the increasing event time.
	events.sort(sortevent());
	printStatus();
//	std::cout<<"event size:"<<events.size()<<std::endl;
}

Scheduler::~Scheduler(){
	events.clear();
	channels.clear();
}

void Scheduler::printStatus(){
	std::cout<<"--------User information---------"<<std::endl;
	std::cout<<"Total Users:"<<npmrUp+npmrDown+npmrRandom+npmrDormant+npmrDvr<<std::endl;
	std::cout<<"Dvr               Users:"<<npmrDvr<<std::endl;
	std::cout<<"Watching-Dormant  Users:"<<npmrDormant<<std::endl;
	std::cout<<"Flipping-Up       Users:"<<npmrUp<<std::endl;
	std::cout<<"Flipping-Down     Users:"<<npmrDown<<std::endl;
	std::cout<<"Flipping-Randomly Users:"<<npmrRandom<<std::endl;
	std::cout<<"--------System information--------"<<std::endl;
	std::cout<<"Total content channels:"<<nsdv<<std::endl;
	std::cout<<"Total under-management channel slices:"<<nslice<<std::endl;
	std::cout<<"Simulation Time:"<<simulationTime<<std::endl;
	std::cout<<"Zipf Parameter:"<<zipfShape<<std::endl;
}

void Scheduler::initEvents(){
	int nUsers=0;
	initEveryEvent(npmrUp,1,nUsers);
	nUsers+=npmrUp;
	initEveryEvent(npmrDown,2,nUsers);
	nUsers+=npmrDown;
	initEveryEvent(npmrRandom,3,nUsers);
	nUsers+=npmrRandom;
	initEveryEvent(npmrDormant,4,nUsers);
	nUsers+=npmrDormant;
	initEveryEvent(npmrDvr,5,nUsers);
}

void Scheduler::initEveryEvent(int npmr, int flipBehavior, int headID){
	for(int i=headID;i<headID+npmr;++i){
		//Initialize one user and the all the events in this user have been initialized
		User user(avgFliptime,avgFlipchannel,avgWatchtime,nsdv,simulationTime,zipfShape,i,flipBehavior);
		users.push_back(user);
		int temp_event_number=user.get_event_number();
		//Push all this user's events into the "events list" in the scheduler
		for(int j=0;j<temp_event_number;++j){
			Event temp_event=user.eventList.front();
			events.push_back(temp_event);
			user.eventList.pop_front();
		}
	}
}

void Scheduler::initChannels(){
		for(int i=0;i<nsdv;++i){
			Channel channel;
			channels.push_back(channel);
	}
}

int Scheduler::getTotalViewers(){
	int totalViewers=0;
	std::vector<Channel> ::iterator ptr=channels.begin();
	while(ptr!=channels.end()){
		totalViewers+=ptr->get_numberofusers();
		ptr++;
	}
	return totalViewers;
}

void Scheduler::execute(){
	std::fstream outPut;
    outPut.open("Datafile.txt", std::ios::out);
	outPut<< "Timestamp for Event"<<"|****|Active channel-slices "<<"|******|Total Viewers"<<"|******|UserId"<<std::endl;
	coreExecute(outPut);
	double avg_channel=0;
	std::vector<Channel> :: iterator channel_ptr=channels.begin();
	//calculate the average number of channel actived during the simulation time.
	while(channel_ptr!=channels.end()){
		//This is to check that the channel is whether actived or deactived when the simulation ends.If it is actived, we should add the adtived time at the tail of the simulation for each channel.
		if(channel_ptr->get_ACTIVE()){
			channel_ptr->set_activation_time(simulationTime);
		}
		double temp=channel_ptr->get_activation_time()/simulationTime;
		avg_channel+=temp;
		channel_ptr++;
	}
	std::cout<<"-------------Statistics-------------"<<std::endl;
	std::cout<<"Average number of channel-slices utilized :  "<<avg_channel<<std::endl;
	std::vector<User> :: iterator user_ptr=users.begin();
	double sum_blocking=0;
	while(user_ptr!=users.end()){
		sum_blocking+=static_cast<double>(user_ptr->get_blocking())/(user_ptr->each_user_event_size+user_ptr->get_blocking());
		user_ptr++;
	}
	std::cout<<"Maximum number of channel-slices observed: " <<  maxChannels<<std::endl;
	std::cout<<"Average blocking probability: "<<100*(sum_blocking/(npmrUp+npmrDown+npmrRandom+npmrDormant+npmrDvr))<<"%"<<std::endl;
	outPut.close();
}

void Scheduler::coreExecute(std::fstream& output){
	bool firstTime=true;
	std::list<Event>::iterator ptr= events.begin();
	while(ptr!=events.end()){
		while(ptr->getEventTime()>simulationTime){
			ptr=events.erase(ptr);
		}
		if(ptr==events.end()){
			break;
		}
		int previous=ptr->get_previous_channel();
		int current=ptr->get_current_channel();
		if(previous==-1){
			if(firstTime)
				firstTime=false;
			else
				events.pop_front();
			if(channels[current].get_numberofusers()==0){
				//If the activeChannels is equal to the nslice, it means that all the channel slices has been allocated. We handle this situation as followings: add the eventTime of the events belonged to this user with 1 second. In otherwords, this user wait a little time and begins to request this channel again, seeing whether there is a free channel at that time.
				if(activeChannels==nslice){
				//add the number of the blocking of this user
					users[ptr->get_user_id()].add_blocking();
					std::list<Event>::iterator updatePtr=events.begin();
					while(updatePtr!=events.end()){
						if(updatePtr->get_user_id()==ptr->get_user_id())
							updatePtr->addEventTime(1);
						updatePtr++;
					} 
					//After add the eventtime of this user, this user's first event probably may not be the first event in the events, so that we need to sort the whole events.
					events.sort(sortevent());
					ptr=events.begin();
					firstTime=true;
					continue;
				}
			// update the actived time of the current channel
				channels[current].set_actived_time(ptr->getEventTime());
				channels[current].set_ACTIVE(true);
				activeChannels++;
				int cur_number=channels[current].get_numberofusers();
				channels[current].set_numberofusers(cur_number+1);
				printtime(output,ptr->getEventTime(),activeChannels, getTotalViewers(), ptr->get_user_id());
				set_max_channels(activeChannels);
			}
			else{
				int cur_number=channels[current].get_numberofusers();
				channels[current].set_numberofusers(cur_number+1);
			}
		}
		else if(previous==nsdv+1){
			if(firstTime)
				firstTime=false;
			else
				events.pop_front();
			if(channels[current].get_numberofusers()==0){
				//same as before, check out whether there is enough room
				if(activeChannels==nslice){
					users[ptr->get_user_id()].add_blocking();
					std::list<Event>::iterator updatePtr=events.begin();
					while(updatePtr!=events.end()){
						if(updatePtr->get_user_id()==ptr->get_user_id()){
							updatePtr->addEventTime(1);
							if(updatePtr->getEventTime()>=simulationTime){
								updatePtr=events.erase(updatePtr);
								continue;
							}
						}
								updatePtr++;
					}
					events.sort(sortevent());
					ptr=events.begin();
					firstTime=true;
					continue;
				}
				//active the current channel
				channels[current].set_actived_time(ptr->getEventTime());
				channels[current].set_ACTIVE(true);
				activeChannels++;
				int cur_number=channels[current].get_numberofusers();
				channels[current].set_numberofusers(cur_number+1);
				printtime(output,ptr->getEventTime(),activeChannels,getTotalViewers(),ptr->get_user_id());
				set_max_channels(activeChannels);
			}
			else{
				int cur_number=channels[current].get_numberofusers();
				channels[current].set_numberofusers(cur_number+1);
			}
		}
		else if(current==nsdv+1){
			if(channels[previous].get_numberofusers()==1){
				//deactive the previous channel because the only user depatures this channel 
				channels[previous].set_deactived_time(ptr->getEventTime());
				channels[previous].set_activation_time(ptr->getEventTime());
				channels[previous].set_ACTIVE(false);
				activeChannels--;
				int pre_number=channels[previous].get_numberofusers();
				channels[previous].set_numberofusers(pre_number-1);
				printtime(output, ptr->getEventTime(),activeChannels,getTotalViewers(),ptr->get_user_id());
				set_max_channels(activeChannels);
			}
			else{
				int pre_number=channels[previous].get_numberofusers();
				channels[previous].set_numberofusers(pre_number-1);
			}
		}
		else{
			if(firstTime)
				firstTime=false;
			else
				events.pop_front();
			if(channels[previous].get_numberofusers()==1){
				//deactive the previous channel because the only user depatures this channel 
				channels[previous].set_deactived_time(ptr->getEventTime());
				channels[previous].set_activation_time(ptr->getEventTime());
				channels[previous].set_ACTIVE(false);
				activeChannels--;
				int pre_number=channels[previous].get_numberofusers();
				channels[previous].set_numberofusers(pre_number-1);
				printtime(output, ptr->getEventTime(),activeChannels,getTotalViewers(),ptr->get_user_id());
				set_max_channels(activeChannels);
			}
			else{
				int pre_number=channels[previous].get_numberofusers();
				channels[previous].set_numberofusers(pre_number-1);
			}
			if(channels[current].get_numberofusers()==0){
				//same as before, check out whether there is enough room
				if(activeChannels==nslice){
					users[ptr->get_user_id()].add_blocking();
					std::list<Event>::iterator updatePtr=events.begin();
					while(updatePtr!=events.end()){
						if(updatePtr->get_user_id()==ptr->get_user_id()){
							updatePtr->addEventTime(1);
							if(updatePtr->getEventTime()>=simulationTime){
								updatePtr=events.erase(updatePtr);
								continue;
							}
						}
								updatePtr++;
					}
					events.sort(sortevent());
					ptr=events.begin();
					firstTime=true;
					continue;
				}
				//active the current channel
				channels[current].set_actived_time(ptr->getEventTime());
				channels[current].set_ACTIVE(true);
				activeChannels++;
				int cur_number=channels[current].get_numberofusers();
				channels[current].set_numberofusers(cur_number+1);
				printtime(output,ptr->getEventTime(),activeChannels,getTotalViewers(),ptr->get_user_id());
				set_max_channels(activeChannels);
			}
			else{
				int cur_number=channels[current].get_numberofusers();
				channels[current].set_numberofusers(cur_number+1);
			}
		}
		ptr++;
	}
}





